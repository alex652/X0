# X0
Joc de x și 0
